#!/usr/local/bin/python
# DreamWorks Animation LLC Confidential Information.
# TM and (c) 2014 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
"""
Application module for td_testmap_compare.
"""
__author__ = "Michael Ross"

import sys, os, re, filecmp
import studioenv
import studio.framework.app
import studio.system.command

from studio.utils.path import Path
from studio import io

class App(studio.framework.app.App):
    """
    Displays the interesting files contained in a testmap and whether they
    differ from their non-testmap counterparts.

    Example:
            
        Compare everything in the testmap /rel/test/GCRWD-1041 to the
        current production environment without testmaps.
    
            td_testmap_compare GCRWD-1041
            or
            td_testmap_compare /rel/test/GCRWD-1041
    """

    def addCmdlineFlags(self, cl):
        """Adds command line flags to the application.
        Parameters cl
                Instance of an studio.utils.cmdline object.
        """
        super(App, self).addCmdlineFlags(cl)
        cl.addArg('testmaps ...',
                  'Testmaps to search through.',
                  convert=lambda p: Path(p, self.ani),
                  )
        cl.addFlag('-folio_path <str>',
                   'Alternate path to use instead of a_folio_path',
                   )
        cl.addFlag('-color', 'Use color in the output')
        cl.addFlag('-include_testmaps',
                   'By default, if no folio path is given with -folio, then '
                   'the current a_folio_path is used with all testmaps '
                   'stripped out.  -include_testmaps will include any '
                   'testmaps in the current environment.',
                   flagAliases=['-include_test_maps'],
                   )
        cl.addFlag('-all', 'Show files that match the current environment')
        cl.addFlag('-diff_cmd <cmd>' ,
                   'Print this string instead of "diff" when printing '
                   'differing files')
        cl.addFlag('-meld', 'Alias for -diff_cmd meld')
        
    def configureOptions(self, opts):
        """Configures the application options.
        """
        opts = super(App, self).configureOptions(opts)
        if opts['meld']:
            opts['diff_cmd'] = 'meld'
        if not opts['folio_path']:
            opts['folio_path'] = self._getFolioPathFromEnv()
        if not self.opts['include_testmaps']:
            pathElts = [p for p in opts['folio_path'].split(':')
                        if '/rel/test/' not in p]
            opts['folio_path'] = ':'.join(pathElts)
        return opts

    def _getFolioPathFromEnv(self):
        if 'a_folio_path' in self.ani:
            folioPath = self.ani['a_folio_path']
        # Folio path won't exist if you're outside the job tree, e.g. in an
        # accurev workspace.  However, the JOB env variable is still set, so
        # we can get a general cm_path.
        elif 'JOB' in os.environ:
            cmd = 'env_wrapper -je %s cm_path' % (os.environ['JOB'])
            lines = studio.system.command.run(cmd, None, showOutput=False)
            folioPath = lines[-1]
        else:
            raise ValueError("Unable to determine folio path, you need to "
                             "be in a job tree")
        return folioPath

    def main(self):
        """Application entry point."""
        super(App, self).main()
        testFiles = self.getTestmapComparisons(self.opts['testmaps'])
        self.printChangedFiles(testFiles)

    def printChangedFiles(self, comparisons):
        """"""
        colors = {'new': io.color.FG_WHITE,
                  'same': io.color.FG_WHITE,
                  'diff': None}
        rows = []
        for comparison in comparisons:
            status = comparison.getStatusString(self.opts['color'],
                                                self.opts['diff_cmd'])
            if self.opts['all'] or comparison.getStatus() != "same":
                rows.append(status.split())
        lines = Table(rows).getLines()
        io.write("\n".join(lines))
        
    def getTestmapComparisons(self, testmaps):
        """
        :Parameters:
            testmaps : `Path list`
                List of testmaps, either in shorthand  (e.g. "SMEKTD-2633")
                or absolute (e.g. "/rel/test/SMEKTD-2633")
        :Returns:
            Comparison objects for all important files from a testmap. Some
            standard .pyc, and .pyo files are filtered out, and only files
            from python2.7 and bin are considered.
        :Rtype:
            `Comparison list`
        """
        realTestmaps = []
        for tm in testmaps:
            if tm.exists():
                realTestmaps.append(tm)
            else:
                relTestFile = Path('/rel/test/' + tm, self.ani)
                if relTestFile.exists():
                    realTestmaps.append(relTestFile)
        comparisons = []
        for tm in realTestmaps:
            files = tm.files(recursive=True, followSymlinks=True)
            for f in files:
                c = getComparison(f, self.opts['folio_path'])
                if c.isInteresting():
                    comparisons.append(c)
        return comparisons


class Comparison(object):
    """
    Stores data about a comparison between two files.

    comparison.getStatus() is set by the getStatus() method. 
    """
    def __init__(self, testFile, folioPath):
        """
            path : `Path`
                A path to a file starting with /rel/test/<testmap>
            folioPath : `str`
               A path like a_folio_path.
        """
        self.testFile = testFile
        self.folioPath = folioPath
        self._status = None
        self.notes = []

    def compareFiles(self, a, b, shallow=True):
        """
        :Returns:
            True if file a matches b
        :Rtype:
            `bool`
        """
        # ignore lines starting with __version__ =
        if a == b:
            return True
        def filt(line):
            return not line.startswith("__version__ =")
        aLines = filter(filt, Path(a).readLines())
        bLines = filter(filt, Path(b).readLines())
        return aLines == bLines

    def isInteresting(self):
        """
        :Returns:
            True if this file is considered interesting enough to report.
            This filters out metadata files, pyc and pyo files,
            and __init__.py files that have meaningful differences from
            the rest of the environment.
        :Rtype:
            `bool`
        """
        f = self.testFile
        if f.endswith('.sourceMap'):
            return False
        if '/METADATA/' in f:
            return False
        if '/python2.6/' in f or '/python2.5/' in f:
            return False
        if f.ext in ['.pyc', '.pyo']:
            return False
        if f.endswith('__init__.py'):
            folioFile = self.folioFile
            if folioFile is not None:
                return self.getStatus() == "diff"
            return False
        return True

    def checkOtherPythonVersions(self):
        """
        If this is a python2.7 files, make sure it matches any python2.6
        and python2.5 files if they exist.
        :Parameters:
            files : `Path list`
                Paths from a testmap.
        """
        py27 = self.testFile
        if '/python2.7/' in py27:
            py26 = py27.replace('/python2.7/', '/python2.6/')
            if py26.exists():
                if py26.readFile() != py27.readFile():
                    self.notes.append(
                        'Contents of python 2.6 and 2.7 versions differ: '
                        '%s %s' % (py26, py27))

    @property
    def folioFile(self):
        """
        :Returns:
            The path to the correspoding file in the given folio path,
            or None if none was found.
        :Rtype:
            `Path|None`
        """
        folioPath = self.folioPath
        testFile = self.testFile
        if not hasattr(self, '_folioFile'):
            folios = folioPath.split(':')
            testBase = '/'.join(testFile.split('/')[:4])
            for folio in folios:
                folioFile = testFile.replace(testBase, folio)
                if folioFile.exists():
                    self._folioFile = folioFile
                    break
            else:
                self._folioFile = None
        return self._folioFile
    
    def getStatus(self):
        """
        :Returns:
            Set and return self._status
        :Rtype:
            `str`
        """
        if self._status is not None:
            return self._status
        folioFile = self.folioFile
        if folioFile is None:
            self._status = "new"
        else:
            if self.compareFiles(self.testFile, folioFile):
                self._status = "same"
            else:
                self._status = "diff"
        self.checkOtherPythonVersions()
        return self._status

    def getStatusColorDict(self):
        """
        :Returns:
            A mapping of status strings to color strings.  Lines with the
            given status will be hilited in that color.
        :Rtype:
            `dict`
        """
        return {'new': io.color.FG_WHITE,
                'same': io.color.FG_WHITE,
                'diff': ""}

    def getStatusString(self, doColor, diffCmd=None):
        """
        :Returns:
            A string to display this comparison's status.
        :Rtype:
            `str`
        """
        status = self.getStatus()
        color = self.getStatusColorDict()[status]
        colorize = self.colorize if doColor else lambda a,b: a
        if status == "new":
            return colorize("new  %s " % self.testFile, color)
        else:
            if status == "diff" and diffCmd is not None:
                status = diffCmd
            return colorize("%-4s %s %s" % 
                            (status, self.testFile, self.folioFile), color)
        if self.notes:
            return colorize("\n".join(self.notes), io.color.FG_YELLOW)
        
    def colorize(self, msg, color=None):
        if not color:
            return msg
        return "%s%s%s" % (color, msg, io.color.NORMAL)

class InitComparison(Comparison):
    """
    A comparison between __init__.py files.  __init__.pys can contain a lot
    of comments that technically differ but result in identical code.  We
    definitely want to flag find any init files that actually differ, so an
    InitComparison strips comments and expected code blocks from the file
    contents and compares the filtered results.
    """

    def getStatusColorDict(self):
        # Differing __init__.py files can be really dangerous and
        # unintentinoal, so highlight them.
        # 
        d = super(InitComparison, self).getStatusColorDict().copy()
        d['diff'] = io.color.FG_YELLOW
        return d

    def compareFiles(self, a, b):
        textA = self._getNonstandardInitLines(a)
        textB = self._getNonstandardInitLines(b)
        return not textA != textB

    def _getNonstandardInitLines(self, init):
        """
        :Parameters:
            init : `str`
                Path to an __init__.py
        :Returns:
            Any nonstandard lines appearing in the given __init__.py file.
        :Rtype:
            `str`
        """
        with open(init, 'r') as f:
            lines = f.readlines()
        lines = [L for L in lines if not self._isRemovable(L)]
        text = "".join(lines)
        regex = re.compile(r'""".*?"""', flags=re.MULTILINE|re.DOTALL)
        text = re.sub(regex, '', text)
        # Remove blank lines... again...
        text = "\n".join([L for L in text.splitlines() if L.strip()])
        return text

    def _isRemovable(self, line):
        stripped = line.strip()
        if not stripped:
            return True
        if stripped.startswith('#'):
            return True
        if stripped.startswith('__version__'):
            return True
        if re.match('from \S+ import __doc__', stripped):
            return True
        # if stripped.startswith(':TMPL:'):
        #     return True
        # if stripped == '"""':
        #     return True
        if stripped in ('from pkgutil import extend_path',
                        '__path__ = extend_path(__path__, __name__)'):
            return True
        return False

class Table(object):
    
    def __init__(self, rows):
        self.rows = rows

    def getLines(self):
        """
        :Parameters:
            rstrip : `bool`
                If True, strip trailing whitespace of each line.
        :Returns:
            List of strings where output is arranged in a table.
        :Rtype:
            `str list`
        """
        if not self.rows:
            return []
        numCols = max(map(len, self.rows))
        colWidths = [0] * numCols

        # find column widths
        # 
        for row in self.rows:
            for i,cell in enumerate(row):
                colWidths[i] = max(colWidths[i], len(self.decolorize(cell)))

        # create output
        # 
        lines = []
        for row in self.rows:
            cells = [str(c).ljust(colWidths[i]) for i,c in enumerate(row)]
            line = " ".join(cells).rstrip()
            lines.append(line)
        return lines
                        
                
    def decolorize(self, string):
        """
        Returns the given string contents without color.
        :Parameters:
            stream : `str`
                A string
        """
        return re.sub("\x1b\\[\\d+m", "", string)

def getComparison(testFile, folioPath):
    if Path(testFile).endswith('__init__.py'):
        return InitComparison(testFile, folioPath)
    return Comparison(testFile, folioPath)

if __name__ == '__main__':
    App().run(sys.argv)

# TM and (c) 2014 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
