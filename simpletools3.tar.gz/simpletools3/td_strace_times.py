#!/usr/local/bin/python
# DreamWorks Animation LLC Confidential Information.
# TM and (c) 2013 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
"""
Run a command and print the times spent reading files.
"""
__author__ = "Michael Ross"

import sys, os, re, tempfile, time
import studioenv
import studio.framework.app
import studio.system.command
from collections import defaultdict
from studio import io

class App(studio.framework.app.App):
    """
    Prints the times taken to open and read all files accessed by a command.
    Columns:
        opens            Number of times the file was opened
        open time        Total time spent opening this file.
        open max         Max time spent to open the file once.
        read time        Total time spent reading this file.
        read max         Max time spent on one read call to this file.
        write time       Total time spent writing to this file.
        write max        Total time spent writing to this file in one call.
        bytes read       Total number of bytes read from this file.
        bytes written    Total number of bytes written in this file.
    """

    def addCmdlineFlags(self, cl):
        """Adds command line flags to the application.
        Parameters cl
                Instance of an studio.utils.cmdline object.
        """
        super(App, self).addCmdlineFlags(cl)
        cl.addFlag('-cmd <cmd>',
                   'Command to run and time.  Make sure it\'s quoted.',
                   flagAliases=['-command'],
                   )
        cl.addFlag('-logs ...',
                   'Paths to a log of strace output.  Strace must have been '
                   'run with the -f and -T flags for meaningful results.',
                   flagAliases=['-log'],
                   )
        cl.addFlag('-pid <pid>',
                   'A process id to run strace on.',
                   )
        cl.addFlag('-sort <key>',
                   'Sort by column value (options: open, stat, read, '
                   'bytes_read, bytes_written)',
                   default='open')
        cl.addFlag('-precision <int>',
                   'Display values to the nth decimal.',
                   default=2,
                   convert=int)
        cl.addFlag('-pid_summary',
                   'Output summary for pid instead of a summary per path'
                   )
                   

    def configureOptions(self, opts):
        """Configures the application options.
        """
        opts = super(App, self).configureOptions(opts)
        numOpts = sum([1 for opt in ['logs', 'cmd', 'pid'] if opts[opt]])
        if numOpts > 1:
            raise ValueError("Cannot use -cmd, -logs, or -pid together.  Use "
                             "only one.")
        if numOpts == 0:
            raise ValueError("You must use one of -cmd, -pid, or -logs")

        missingLogs = [L for L in opts['logs'] if not os.path.exists(L)]
        if missingLogs:
            raise ValueError("These logs don't exist: %s" % (
                    "\n  ".join(missingLogs)))
        
        return opts

    def main(self):
        """Application entry point."""
        super(App, self).main()

        ReadTime.precision = self.opts['precision']

        if self.opts['cmd']:
            logPaths = [self.runStraceCommand(self.opts['cmd'])]
        elif self.opts['logs']:
            logPaths = self.opts['logs']
        elif self.opts['pid']:
            logPaths = [self.runStraceOnPid(self.opts['pid'])]
        readTimes,procs = self.getReadTimesFromLogPaths(logPaths)
        logPathsString = "\n  ".join(logPaths)
        if not readTimes:
            io.warn("Unable to parse any read times from log(s): %s" % 
                     logPathsString)
        else:
            try:
                if self.opts['pid_summary']:
                    summary = procs.getSummary()
                else:
                    summary = ReadTime.getSummary(readTimes,
                                                  sortString=self.opts['sort'])
                io.write(summary)
            except Exception:
                io.warn("Error while getting summary read times from logs: %s" % 
                        logPathsString)
                raise
            io.write("\nLogs appear at %s" % logPathsString)
        
    straceCmdBase = "strace -T -f -etrace=open,read,write,stat,clone"

    def runStraceCommand(self, cmd):
        """
        :Parameters:
            cmd : `str`
                The commandline string to run.
        :Returns:
            String path to a the log file.
        :Rtype:
            `str`
        """
        tempFd, tempPath = tempfile.mkstemp(prefix="td_strace_times_")
        io.write("Piping strace log to %s" % (tempPath))
        os.close(tempFd)
        straceCommand = "%s -o %s %s" % (self.straceCmdBase, tempPath, cmd)
        startTime = time.time()
        try:
            command = studio.system.command.Command(
                straceCommand, showOutput=False, successValues=range(256))
            command.run()
            command.getResults()
        except ValueError:
            io.warn("Process exited with exit code %s: %s" % (
                    command.exitStatus, straceCommand))
        endTime = time.time()
        appRunTime = endTime - startTime
        io.write("Took %.2f to run command %s" % (appRunTime, straceCommand))
        return tempPath

    def runStraceOnPid(self, pid):
        """
        :Parameters:
            pid : `str`
                ProcessID to run strace on.
        :Returns:
            String path to a the log file.
        :Rtype:
            `str`
        """
        tempFd, tempPath = tempfile.mkstemp(prefix="td_strace_times_")
        os.close(tempFd)
        io.write("Piping strace log to %s" % (tempPath))
        straceCommand = "%s -o %s -p %s " % (self.straceCmdBase,tempPath, pid)
        try:
            command = studio.system.command.Command(
                straceCommand, showOutput=False, successValues=range(256))
            command.run()
            command.getResults()
        except ValueError:
            io.warn("Process exited with exit code %s: %s" % (
                    command.exitStatus, straceCommand))
        except KeyboardInterrupt:
            io.write("User aborted strace with keyboard interrupt")
            pass
        return tempPath

    def getReadTimesFromLogPaths(self, logPaths):
        """
        :Parameters:
            logPath : `str list`
                Path to a log files containing strace -T output.
        :Returns:
            Tuple:
              -List of ReadTime objects parsed from the log
              -Processes object used while parsing them.
        :Rtype:
            (`ReadTime list`, `Processes`)
        """
        readTimes = []
        procs = Processes()
        for logPath in logPaths:
            try:
                with open(logPath) as logFile:
                    readTimesTmp, procsTmp = self.getReadTimesFromLogLines(logFile)
            except Exception:
                io.error("Error occurred getting readTimes from %s" % logPath)
                raise
            readTimes += readTimesTmp
            procs.update(procsTmp)
        return readTimes, procs

    def getReadTimesFromLogLines(self, logStream):
        """
        :Parameters:
            logStream : `file`
                An object that will yield lines of a strace log when
                iterated over (e.g. a string list, open file, a pipe)
        :Returns:
            Tuple:
              -List of ReadTime objects parsed from the log
              -Processes object used while parsing them.
        :Rtype:
            (`ReadTime list`, `Processes`)
        """
        readTimes = []
        # dict of ReadTime objects, indexed by pid and file descriptor.
        # activeReadTimes = {}
        procs = Processes()
        
        for line in logStream:

            # strace can split Syscalls across multiple lines, but they can
            # be merged back into a single line with a some bookkeeping and
            # string manipulation.
            # 
            if self.isUnfinishedLine(line):
                io.info("unfinished: %s" % line.rstrip())
                pid = line.split()[0]
                procs[pid].unfinishedLine = line
                continue 
            elif self.isResumedLine(line):
                pid = line.split()[0]
                io.info("resumed: %s" % line.strip())
                prevLine = procs[pid].unfinishedLine
                io.info("previous unfinished: %s" % prevLine.rstrip())
                pid = line.split()[0]
                line = self.mergeUnfinishedLines(prevLine, line)
                io.info("merged: %s" % line)
                
            if self.isCloneLine(line):
                io.info("clone: %s" % line.rstrip())
                pid, childPid = self.parseCloneLine(line)
                procs[childPid] = Proc(childPid, procs[pid])

            elif self.isOpenLine(line):
                io.info("open: %s" % line.rstrip())
                pid, path, fd, seconds = self.parseOpenLine(line)
                rt = ReadTime(path, seconds)
                procs[pid].setReadTime(fd, rt)
                # activeReadTimes[fd] = rt
                readTimes.append(rt)

            elif self.isStatLine(line):
                io.info("stat: %s" % line.rstrip())
                pid, path, seconds = self.parseStatLine(line)
                # io.info("stat: seconds: %s, path: %s" % (seconds, path))
                readTimes.append(StatTime(path, seconds))

            elif self.isReadLine(line):
                io.info("read: %s" % line.rstrip())
                pid, fd, readBytes, seconds = self.parseReadLine(line)
                # io.info(procs)
                proc = procs[pid]
                while fd not in proc.fds and proc.parent is not None:
                    proc = proc.parent
                if fd in proc.fds:
                    readTime = proc.fds[fd] 
                    
                else:
                    readTime = ReadTime('file %s' % fd, 0.0)
                readTime.readTime += float(seconds)
                readTime.readBytes += int(readBytes)
            elif self.isWriteLine(line):
                io.info("write: %s" % line.rstrip())
                pid, fd, writeBytes, seconds = self.parseWriteLine(line)
                # io.info(procs)
                proc = procs[pid]
                while fd not in proc.fds and proc.parent is not None:
                    proc = proc.parent
                if fd in proc.fds:
                    writeTime = proc.fds[fd] 
                else:
                    writeTime = ReadTime('file %s' % fd, 0.0)
                writeTime.writeTime += float(seconds)
                writeTime.writeBytes += int(writeBytes)
            else:
                io.info("unknown: %s" % line.rstrip())

        return readTimes,procs

    def mergeUnfinishedLines(self, unfinishedLine, resumedLine):
        """
        :Parameters:
            unfinishedLine : `str`
                Line ending with <unfinished ...>
            resumedLine : `str`
                Line completing syscall that above line left unfinished.
        """
        pid = resumedLine.split()[0]
        lineStart = unfinishedLine.rstrip().replace("<unfinished ...>", ""),
        lineEnd = resumedLine.split(" ", 1)[-1].split(">", 1)[-1]
        return "%s %s %s" % (pid, lineStart, lineEnd)

    cloneRegex = r'(\d+)\s*clone\(.*\)\s*=\s*(\d+)\s*.*<.*>'
    openRegex  = r'(\d+)\s*open\("(.*)", .*\)\s*=\s*(-?\d+)\s*.*<(.*)>'
    statRegex  = r'(\d+)\s*stat\("(.*)", .*\)\s*=\s*-?\d+\s*.*<(.*)>'
    readRegex  = r'(\d+)\s*read\((\d+), .*, (\d+)\)\s*=\s*\d+ <(.*)>'
    writeRegex = r'(\d+)\s*write\((\d+), .*, (\d+)\)\s*=\s*\d+ <(.*)>'

    def isUnfinishedLine(self, line):
        return line.rstrip().endswith("<unfinished ...>")

    def isResumedLine(self, line):
        return " resumed>" in line and "<... " in line

    def isCloneLine(self, line):
        return re.search(self.cloneRegex, line)

    def isOpenLine(self, line):
        return re.search(self.openRegex, line)

    def isStatLine(self, line):
        return re.search(self.statRegex, line)

    def isReadLine(self, line):
        return re.search(self.readRegex, line)

    def isWriteLine(self, line):
        return re.search(self.writeRegex, line)

    def parseCloneLine(self, line):
        """
        :Returns:
            (pid, childPid)
        :Rtype:
            `tuple`
        """
        return re.search(self.cloneRegex, line).groups()
    
    def parseOpenLine(self, line):
        """
        :Returns:
            (pid, path, file descriptor, time taken)
        :Rtype:
            `tuple`
        """
        return re.search(self.openRegex, line).groups()

    def parseStatLine(self, line):
        """
        :Returns:
            (pid, path, file descriptor, time taken)
        :Rtype:
            `tuple`
        """
        return re.search(self.statRegex, line).groups()

    def parseReadLine(self, line):
        """
        :Returns:
            (pid, file descriptor, bytes read, time taken)
        :Rtype:
            `tuple`
        """
        return re.search(self.readRegex, line).groups()

    def parseWriteLine(self, line):
        """
        :Returns:
            (pid, file descriptor, bytes write, time taken)
        :Rtype:
            `tuple`
        """
        return re.search(self.writeRegex, line).groups()

class ReadTime(object):
    """
    Records the total time spent reading from a file from open until close.
    """
    precision = 2

    def __init__(self, path, openTime,):
        self.path = path
        self.readTime = 0.0
        self.readBytes = 0
        self.writeTime = 0.0
        self.writeBytes = 0.0
        self.openTime = float(openTime)
        self.isStat = False

    @classmethod
    def getSummary(cls, readTimesList, sortString='open'):
        """
        :Parameters:
            readTimesList : `ReadTime list`
                list of ReadTime objects to summarize.
            sortString : `str`
                Sort by open, read, or stat time.  Possible values are
                open, stat, and read.
        :Returns:
            A string of statistics summarizing the given read times.
        :Rtype:
            `str`
        """
        # Create a dict of read times for the list of paths
        # 
        readTimesDict = {}
        for rt in readTimesList:
            if rt.path in readTimesDict:
                readTimesDict[rt.path].append(rt)
            else:
                readTimesDict[rt.path] = [rt]

        # Sort readtimes by total read time.
        def openTimeKey(pair):
            return sum([rt.openTime for rt in pair[1] if not rt.isStat])
        def readTimeKey(pair):
            return sum([rt.readTime for rt in pair[1] if not rt.isStat])
        def statTimeKey(pair):
            return sum([rt.statTime for rt in pair[1] if rt.isStat])
        def writeTimeKey(pair):
            return sum([rt.writeTime for rt in pair[1] if not rt.isStat])
        def bytesReadKey(pair):
            return sum([rt.readBytes for rt in pair[1] if not rt.isStat])
        def bytesWrittenKey(pair):
            return sum([rt.writeBytes for rt in pair[1] if not rt.isStat])
        key = {"open": openTimeKey,
               "read": readTimeKey,
               "stat": statTimeKey,
               "write": writeTimeKey,
               "bytes_read": bytesReadKey,
               "bytes_written": bytesWrittenKey,
               }[sortString]
        sortedReadTimes = sorted(readTimesDict.items(), key=key)

        result = ""

        totalReadBytes = 0
        totalWriteBytes = 0
        totalReadTime = 0
        totalWriteTime = 0
        totalOpenTime = 0
        totalStatTime = 0

        for path,readTimes in sortedReadTimes:

            merged = MergedReadTime(readTimes)
            totalReadBytes += merged.readBytes
            totalWriteBytes += merged.writeBytes
            totalReadTime += merged.readTime
            totalWriteTime += merged.writeTime
            totalOpenTime += merged.openTime
            result += merged.getSummary()
            
        result += "Total seconds spent opening:  %f\n" % (totalOpenTime)
        result += "Total seconds spent statting: %f\n" % (totalStatTime)
        result += "Total seconds spent reading:  %f\n" % (totalReadTime)
        result += "Total seconds spent writing:  %f\n" % (totalWriteTime)
        result += "Total bytes read: %s\n" % (humanReadableSize(totalReadBytes))
        result += "Total bytes written: %s\n" % (humanReadableSize(totalWriteBytes))
        return result

class MergedReadTime(object):

    def __init__(self, readTimes, precision=2):
        self.precision = precision

        # stat timings
        # 
        sts = [rt for rt in readTimes if rt.isStat]
        self.statPaths = sorted(set([st.path for st in sts]))
        
        statTimes = [st.statTime for st in sts]
        self.numStats = len(statTimes)
        self.statTime = sum(statTimes)
        self.statTimeMax = max(statTimes or [0])

        # read timings
        # 
        readTimes = [rt for rt in readTimes if not rt.isStat]
        self.openPaths = sorted(set([rt.path for rt in readTimes]))

        rts = [rt.readTime for rt in readTimes]
        self.readTime  = sum(rts)
        self.readTimeMax = max(rts or [0])

        wts = [rt.writeTime for rt in readTimes]
        self.writeTime  = sum(wts)
        self.writeTimeMax = max(wts or [0])

        self.readBytes = sum([rt.readBytes for rt in readTimes])
        self.writeBytes = sum([rt.writeBytes for rt in readTimes])

        ots = [rt.openTime for rt in readTimes]
        self.numOpens = len(rts)
        self.openTime = sum(ots)
        self.openTimeMax  = max(ots or [0])

    def getSummary(self):
        """
        :Returns:
            String summary of open/read/write/stat statistics of this
            object.
        :Rtype:
            `str`
        """
        # This format string gets formatted twice: Once to replace
        # %(precision)d, then once to replace all the other specified local
        # and instance variables.
        # 
        summaryFormatStr = (
            "opens:\t%%(numOpens)s\t"
            "open time:\t%%(openTime).%(precision)df\t" 
            "open max:\t%%(openTimeMax).%(precision)df\t"
            # "stats:\t%%s\t"
            # "stat time:\t%%.%(precision)df\t"
            # "stat time max:\t%%.%(precision)df\t"
            "read time:\t%%(readTime).%(precision)df\t"
            "read max:\t%%(readTimeMax).%(precision)df\t"
            "bytes read:\t%%(readBytes)d\t"
            "write time:\t%%(writeTime).%(precision)df\t"
            "write max:\t%%(writeTimeMax).%(precision)df\t"
            "bytes written:\t%%(writeBytes)d\t"
            "%%(pathDescription)s\n") % (self.__dict__)
        readBytes = humanReadableSize(self.readBytes)
        writeBytes = humanReadableSize(self.writeBytes)
        paths = (self.openPaths + self.statPaths)
        if len(paths) == 1:
            pathDescription = paths[0]
        elif len(self.openPaths) == 1 and self.openPaths == self.statPaths:
            pathDescription = paths[0]
        else:
            pathDescription = "%d opened paths, %d statted" % (
                len(self.openPaths), len(self.statPaths))
        formatVars = {}
        formatVars.update(locals())
        formatVars.update(self.__dict__)
        summary = summaryFormatStr % (formatVars)
        return summary


class StatTime(ReadTime):
    def __init__(self, *args, **kwargs):
        super(StatTime, self).__init__(*args, **kwargs)
        self.statTime = self.openTime
        self.isStat = True

class Proc(object):
    
    def __init__(self, pid, parent=None):
        self.pid = pid
        self.fds = {'0': ReadTime("%s stdin" % pid, 0),
                    '1': ReadTime("%s stdout" % pid, 0),
                    '2': ReadTime("%s stderr" % pid, 0)}
        self.children = {}
        self.parent = parent
        self.unfinishedLine = ""
        self.allReadTimes = [self.fds['0'], self.fds['1'], self.fds['2']]

    def setReadTime(self, fd, readTime):
        """
        :Parameters:
            fd : `str`
                String of the file descriptor id (e.g. "3", "4")
            readTime : `ReadTime`
                ReadTime to add to this proc.
        """
        self.fds[fd] = readTime
        self.allReadTimes.append(readTime)

    def __repr__(self):
        return ("Proc = {\n"
                "  pid: %s\n" % self.pid +
                "  parent: %s\n" % (self.parent.pid if self.parent else None) +
                "  fds: %s\n" % self.fds +
                "  children: %s\n" % ", ".join([p.pid for p in self.children]) +
                "  }"
                )
    
    def getSummary(self):
        """
        Print a summary of the merged timings of this process.
        """
        merged = MergedReadTime(self.allReadTimes)
        return merged.getSummary()
        
        
class Processes(defaultdict):
    def __missing__(self, pid):
        proc = Proc(pid)
        self[pid] = proc
        return proc

    def getSummary(self):
        result = ""
        for pid,proc in self.items():
            result += "%s: %s\n" % (pid, proc.getSummary())
        return result
            

def humanReadableSize(num):
    """
    :Parameters:
        num : `int`
            Number of bytes to convert to human readable format.
    :Returns:
        The given number of bytes in a human readable format.
    :Rtype:
        `str`
    """
    labels = ['Bytes','K','M','G','T']

    if '-kilo' in sys.argv or '-k' in sys.argv:
        labels.pop(0)

    for label in labels:
        if num < 10.0:
            return "%3.1f%s" % (num, label)
        elif num < 1024.0:
            return "%3.0f%s" % (num, label)
        num /= 1024.0


if __name__ == '__main__':
    App().run(sys.argv)

# TM and (c) 2013 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
