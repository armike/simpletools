#!/usr/local/bin/python
# ----------------------------------------------------------------------
# TM and (c) 2009 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
# ----------------------------------------------------------------------
"""
"""
__author__ = "Michael Ross"

import sys, os, filecmp, re, time, multiprocessing.pool
import studioenv
import studio.framework.app
import studio.system.command

from studio.utils.sort import alphaNumericSort
from studio.utils.path import Path
from studio import io

class App(studio.framework.app.App):
    """
    Sorts the given list of files by their modified time, then shows only files
    that are different than their more recent neighbor.
    """

    def addCmdlineFlags(self, cl):
        """Adds command line flags to the application.
        Parameters cl
                Instance of an studio.utils.cmdline object.
        """
        super(App, self).addCmdlineFlags(cl)
        cl.addArg('targets ...', 'The file(s) to lookup snapshots for')
        cl.addFlag('-deep',
                   'When comparing files, compare contents and not just '
                   'stat data.')
        cl.addFlag('-diff',
                   'Diff the most recent different files.')
        cl.addFlag('-diff_cmd <cmd>',
                   'When using -diff, use this cmd to diff the files',
                   default='diff')
        cl.addFlag('-no_sort',
                   'Instead of sorting by date, compare files in the order '
                   'they are given.',
                   )
        cl.addFlag('-all',
                   'diff all files against all other files and print each '
                   'set of matching files in a group.',
                   )
        cl.addFlag('-prefer ...',
                   'If using -all, list these items first in the output.'
                   )
        cl.addFlag('-gui',
                  'Alias for -diff_cmd meld',
                  )

    def configureOptions(self, opts):
        """Configures the application options.
        """
        opts = super(App, self).configureOptions(opts)

        opts['targets'] = [Path(f, self.ani) for f in opts['targets']]

        # Go down the list of gui commands in case you're on an old system.
        # 
        if opts['gui']:
            for guiCommand in ['meld', 'xxdiff', 'xdiff']:
                try:
                    studio.system.command.which(guiCommand, None)
                    opts['diff_cmd'] = guiCommand
                    break
                except ValueError:
                    pass
            else:
                io.warn("No gui diffs found, using diff")
                opts['diff_cmd'] = "diff"

        return opts

    def main(self):
        """Application entry point."""
        super(App, self).main()
        
        if self.opts['all']:
            self.compareAllFiles(self.opts['targets'])
        else:
            uniques = self.getUniques(self.opts['targets'], self.opts['deep'])
            if self.opts['diff']:
                self.diffSnapshot(uniques[0], uniques[1])
            else:
                io.write("\n".join(uniques))

    def getUniques(self, paths, deep):
        """
        :Parameters:
            paths : `Path list`
            deep : `bool`
                Compare contents of the paths, not just their stat
                results.
        :Returns:
            A filtered list of paths, where each path returned has different
            contents than the paths adjacent to it.
        :Rtype:
            `Path list`
        """
        if not self.opts['no_sort']:
            filtered = sorted(paths, key=lambda p: -p.modifiedTime)

        # Filter out everything that has similar stat results.
        # 
        filteredTmp = [filtered[0]]
        for i in range(1, len(filtered)):
            current = filtered[i]
            prev = filtered[i-1]
            if not filecmp.cmp(current, prev):
                filteredTmp.append(current)

        filtered = filteredTmp

        if deep:
            filteredTmp = []
            for i in range(1, len(filtered)):
                if not filecmp.cmp(current, prev, shallow=False):
                    filteredTmp.append(current)
            filtered = filteredTmp

        return filtered

    def diffFiles(self, pathA, pathB):
        """
        :Parameters:
            pathA : `str`
            pathB : `str`
        """
        cmd = "%s %s %s" % (self.opts['diff_cmd'], pathA, pathB)
        io.write("%s" % (cmd), color=io.color.FG_BLUE)
        studio.system.command.run(cmd, None, successValues=[0,1])

    def compareAllFiles(self, fileList, threaded=True):
        comparables = [FileComparable(f, not self.opts['deep']) for f in fileList]
        return self.compareAll(comparables, threaded)

    def compareAll(self, comparables, threaded=True):
        """
        :Parameters:
            comparables : `Comparable list`
            
        """
        matchingImageSets = UnorderedPair.compareAll(comparables)
        matchingImageLists = [
            sorted(imgSet, cmp=alphaNumericSort, key=lambda img:img.path)
            for imgSet in matchingImageSets]

        # Take into account the high priority names listed by the user.
        # High priority names appear first, so we want to move those last,
        # so we reverse the list of regular expressions given.
        # 
        if self.opts['prefer']:
            prefs = reversed(self.opts['prefer'])
            for images in matchingImageLists:
                for pref in prefs:

                    # Reversing images will cause high priority images to be
                    # moved to the front of the list in alphabetical order,
                    # if multiple names match the expression.  This should
                    # hopefully be the expected behavior.
                    # 
                    for image in reversed(images):
                        if re.match(pref, image.path):
                            images.remove(image)
                            images.insert(0, image)
                            break

        for matchingImages in matchingImageLists:
            imgStrings = [str(img) for img in matchingImages]
            io.write(" ".join(imgStrings))
            io.write("")

            # if self.opts['remove']:
            #     paths = [img.path for img in matchingImages[1:]]
            #     io.write("Removing: %s" % " ".join(paths))
            #     for path in paths:
            #         path.remove()

class UnorderedPair(object):
    """
    A container for two things can be compared to one another with a single
    argument matches() method, e.g. a.matches(b).
    """

    def __init__(self, a, b):
        """
        :Parameters:
            a : `Pair`
            b : `Pair`
        """
        self.a = a
        self.b = b
        self._isEqual = None
        
    def __eq__(self, other):
        """
        :Returns:
            True iff this pair's contents is the same as the given
            UnorderedPair, regardless of order.  Does not use matches(),
            but directly compares the objects.
        :Rtype:
            `bool`
        """
        return ((self.a == other.a and self.b == other.b) or
                (self.a == other.b and self.b == other.a))

    def __contains__(self, x):
        """
        :Parameters:
            x : `object`
        :Returns:
            True iff x is one of the object in this pair.
        :Rtype:
            `bool`
        """
        return (x == self.a or x == self.b)

    def isEqual():
        doc = """True iff self.a.matches(self.b)."""
        def fget(self):
            if self._isEqual is None:
                self._isEqual = self.a.matches(self.b)
            return self._isEqual
        return locals()
    isEqual = property(**isEqual())

    @classmethod
    def compareAll(cls, items, threaded=True, maxThreads=None):
        """
        Compare all items in the list to each other.  Ignores self
        comparisons (a.matches(a)) and duplicate comparisons (a.matches(b)
        and b.matches(a))
        :Parameters:
            items : `object`
                Some object with a match method
            threaded : `bool`
                Run multithreaded.
            maxThreads : `int | None`
                Max number of threads to use during comparison, or None
                to use the system's number of cpus.
        :Returns:
            A list of lists, where each inner list contains items that
            are identical.
        :Rtype:
            `list of item sets`
        """
        pairs = []
        for a,itemA in enumerate(items):
            for itemB in items[a+1:]:
                pairs.append(UnorderedPair(itemA, itemB))
        
        io.info("Running %d comparisons" % len(pairs))

        st = time.time()
        if not threaded:
            io.info("Running non-threaded comparisons")
            for pair in pairs:
                pair.isEqual
        else:
            io.info("Running threaded comparisons")
            pool = multiprocessing.pool.ThreadPool(processes=maxThreads)
            def runComparison(somePair):
                return somePair.isEqual
            pool.map(runComparison, pairs)

        et = time.time()
        io.info("Time to compare all images: %.2fs" % (et-st))

        itemLists = cls.groupSimilarPairs(pairs)
        return itemLists

    @classmethod
    def groupSimilarPairs(cls, pairs):
        """
        :Parameters:
            pairs : `Pair list`
                List of pairs that have already been compared.
        :Returns:
            Given a set of pairs that have been compared, group all pairs'
            contents into lists of items that are identical.
        :Rtype:
            `list of sets`
        """
        # Extract both items of each pair into an equality dict, where
        # equalities[k] returns the set of all items equal to item k,
        # including k itself.  When finished, the values of that dict are
        # our answer, once we remove any duplicates.
        # 
        equalities = {}
        for pair in pairs:
            if pair.isEqual:
                a = pair.a
                b = pair.b
                
                if a not in equalities:
                    if b in equalities:
                        equalities[a] = equalities[b]
                    else:
                        equalities[a] = set([a,b])
                else:
                    equalities[a].add(b)

                if b not in equalities:
                    if a in equalities:
                        equalities[b] = equalities[a]
                    else:
                        equalities[b] = set([b,a])
                else:
                    equalities[b].add(a)
                
        uniqueEqualitySets = []
        for equalitySet in equalities.values():
            if equalitySet not in uniqueEqualitySets:
                uniqueEqualitySets.append(equalitySet)
        return uniqueEqualitySets

class FileComparable(object):

    def __init__(self, path, deep=True):
        """
        :Parameters:
            path : `str`
                Path to the image on disk.
            deep : `bool`
                Only compare stat values, not file contents.
        """
        self.path = Path(path)
        self.deep = deep

    def __repr__(self, path):
        return 'Image(%s)' % repr(path)
    
    def __str__(self):
        return str(self.path)

    def __eq__(self, other):
        return self.path == other.path

    def matches(self, other):
        """
        :Parameters:
            other:  `Image`
                Another image to compare against.
        :Returns:
            True iff this image matches other, False o.w.
        :Rtype:
            `bool`

        """
        if self.path == other.path:
            return True
        if filecmp.cmp(self.path, other.path, shallow=True):
            return True
        if not self.deep:
            return False
        return filecmp.cmp(self.path, other.path, shallow=False)

if __name__ == '__main__':
    App().run()
# ----------------------------------------------------------------------
# TM and (c) 2009 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
# ----------------------------------------------------------------------
