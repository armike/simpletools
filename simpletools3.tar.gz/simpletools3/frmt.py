"""
Formatting utilities.  Named "frmt" so "format" is still available as a
variable name.

This can be considered a markup language in code.  This modules allows the
user to create richly formatted text without committing to a particular
output format up front.  For instance, a single set of messages can be
translated into a wiki, an html email, terminal output, or text fit for a
hey.

There are two types of objects involved, Format objects and Message objects.
Message objects store the data that will be reported without committing to
an output format.  Once the data is ready to be reported, a Format class
parses Message objects and returns a string that will present the data
nicely in some particular format (e.g. email, wiki, terminal, etc.). 
"""
__author__ = "Michael Ross"

import sys, os, struct, fcntl, termios, tempfile
import studioenv
import re, time
from studio import io
# import matplotlib.pyplot as plt

class Format(object):
    """
    """
    newline = NotImplementedError

    def formatMessage(self, message):
        """
        Format the given message with this format type.
        Use this when you don't know if something is a Message, str, int, or
        whatever.  If you know it's a message, you can use
        <message>.formatted(format)

        :Parameters:
            message : `Message`
                Accepts a Message or applies str() to non-Messages.
            format : `Format`
        :Returns:
            Formatted message
        :Rtype:
            `str`
        """
        if isinstance(message, Message):
            return str(message.formatted(self))
        if isinstance(message, list):
            return self.formatMessages(message)
        else:
            return str(message)

    def formatMessages(self, messages):
        """
        Convenience method to format a list of messages and return a list
        :Parameters:
            messages : `Message`
                Accepts a Message or apples str() to non-Messages.
            format : `Format`
        :Returns:
            List of formatted messages
        :Rtype:
            `str list`
        """
        return [self.formatMessage(msg) for msg in messages]

    def join(self, messages):
        """
        :Parameters:
            messages : `Message list`
        :Returns:
            Formatted list of messages, joined with the newline separator.
        :Rtype:
            `str`
        """
        return self.newline.join(self.formatMessages(messages))

    @classmethod
    def maxWidth(cls):
        """
        :Returns:
            The agreed upon maximum width of the window this will be displayed
            in, or 0 if not applicable
        :Rtype:
            `int`
        """
        return 0

class TerminalFormat(Format):
    newline = "\n"

    @classmethod
    def maxWidth(cls):
        return terminalWidth()

    @classmethod
    def bar(cls):
        return "-"*terminalWidth()

    @classmethod
    def webLink(cls, text, url):
        return text

    @classmethod
    def anchorLink(cls, text, url):
        return text

    @classmethod
    def anchor(cls, text, name):
        return text

    @classmethod
    def bold(cls, text):
        return cls.colorize(text, io.color.BOLD)

    @classmethod
    def header(cls, text, level=1):
        return cls.colorize(text, io.color.BOLD)

    @classmethod
    def colorize(cls, text, color):
        return "%s%s%s" % (color, text, io.color.NORMAL)

    @classmethod
    def date(cls, seconds):
        """
        :Parameters:
            seconds : `int`
                posixTime
        :Returns:
            A date string in the format e.g. Wed Aug 24 12:23 format.
        :Rtype:
            `str`
        """
        timeTuple = time.localtime(seconds)
        return time.strftime("%a %b %d %H:%M", timeTuple)

class HeyFormat(Format):
    newline = "\n"

    def formatMessage(self, message):
        msg = super(HeyFormat, self).formatMessage(message)
        return decolorize(msg)

    @classmethod
    def maxWidth(cls):
        return 160

    @classmethod
    def bar(cls):
        return "-" * cls.heyWidth

    @classmethod
    def webLink(cls, text, url):
        return text

    @classmethod
    def anchorLink(cls, text, url):
        return text

    @classmethod
    def anchor(cls, text, name):
        return text

    @classmethod
    def bold(cls, text):
        return text

    @classmethod
    def header(cls, text, level=1):
        return text

    @classmethod
    def colorize(cls, text, color):
        return text

    @classmethod
    def date(cls, seconds):
        """
        :Parameters:
            seconds : `int`
                posixTime
        :Returns:
            A date string in the format e.g. Wed Aug 24 12:23 format.
        :Rtype:
            `str`
        """
        timeTuple = time.localtime(seconds)
        return time.strftime("%a %b %d %H:%M", timeTuple)


class EmailFormat(Format):
    newline = "<br>"

    def __init__(self):
        super(EmailFormat, self).__init__()

        # Image paths that will need to be attached to the email.
        # Keys image names, values are paths to the image on disk.
        # 
        self.imagePaths = {}
        
    def addImage(self, cid, imgPath):
        """
        :Parameters:
            cid : `str`
                Content id used to retrieve the image.
            imgPath : `str`
                Path to the image on disk
        """
        self.imagePaths[cid] = imgPath

    @classmethod
    def webLink(cls, text, url):
        return '<a href="%s">%s</a>' % (url, text)

    @classmethod
    def anchorLink(cls, text, anchor):
        return text
        # return '<a href="#%s">%s</a>' % (anchor, text)

    @classmethod
    def anchor(cls, text, anchor):
        return text
        # return '<a anchor="%s">%s</a>' % (anchor, text)

    @classmethod
    def bar(cls):
        return "<hr>"

    @classmethod
    def bold(cls, text):
        return "<b>%s</b>" % text

    @classmethod
    def header(cls, text, level=1):
        levelToFontSize = {1: 6,
                           2: 4,
                           3: 2,
                           4: 1,
                           }
            
        return '<font size="%d">%s</font>' % (levelToFontSize[level], text)

    @classmethod
    def colorize(cls, text, color):
        return "%s%s%s" % (color, text, io.color.NORMAL)

    @classmethod
    def date(cls, seconds):
        """
        :Parameters:
            seconds : `int`
                posixTime
        :Returns:
            A date string in the format e.g. Wed Aug 24 12:23 format.
        :Rtype:
            `str`
        """
        timeTuple = time.localtime(seconds)
        return time.strftime("%a %b %d %H:%M", timeTuple)


class WikiFormat(Format):
    newline = "\n"

    @classmethod
    def webLink(cls, text, url):
        return "[%s|%s]" % (text, url)

    @classmethod
    def anchorLink(cls, text, anchor):
        return '[%s|#%s]' % (text, anchor)

    @classmethod
    def anchor(cls, text, anchor):
        return '{anchor:%s}%s' % (anchor, text)

    @classmethod
    def bar(cls):
        return "----"

    @classmethod
    def bold(cls, text):
        return "*%s*" % text

    @classmethod
    def header(cls, text, level=1):
        return 'h%s. %s' % (level, text)

    @classmethod
    def colorize(cls, text, color):
        return "%s%s%s" % (color, text, io.color.NORMAL)

    @classmethod
    def date(cls, seconds):
        """
        :Parameters:
            seconds : `int`
                posixTime
        :Returns:
            A sortable date string, e.g. 2012-08-17 12:23:45 (Wed Aug 24) format.
        :Rtype:
            `str`
        """
        timeTuple = time.localtime(seconds)
        return time.strftime("%m-%d %H:%M:%S (%a %b %d)", timeTuple)


class Message(object):
    """
    Class to describe a basic frmt object.  All subclasses should
    support these methods.
    """
    def formatted(self, format):
        """
        format : `Format`
            A Format object that determines how this message is formatted.
        """
        raise NotImplementedError("%s has not implemented formatted" % 
                                  (self.__class__.__name__))

class WebLink(Message):
    """Link to an external webpage"""
    def __init__(self, message, url):
        super(WebLink, self).__init__()
        self.message = message
        self.url = url
        
    def formatted(self, format):
        contents = format.formatMessage(self.message)
        return format.webLink(contents, self.url)        


class Line(Message):
    """A string line with Message objects embedded."""
    def __init__(self, *args):
        self.messageList = args

    def formatted(self, format):
        msg = ""
        for message in self.messageList:
            msg += format.formatMessage(message)
        return msg


class QLinkGroup(Message):
    """Link to a group on the q page"""
    def __init__(self, groupId, text=None):
        """
        :Parameters:
            groupId : `str`
                A group ID, e.g. 11041134, 11041134.1, 11041134.2.104
            text : `str`
                If given, this will be displayed instead of the group ID
        """
        self.groupId = groupId
        self.text = text

    def formatted(self, format):
        split = str(self.groupId).split('.')
        groupId = split[0]
        url = "http://q/cgi-bin/group_detail.cgi?groupid=%s" % (groupId)
        displayText = self.text if self.text is not None else self.groupId
        return format.webLink(displayText, url)

class QLinkItemLog(Message):
    """Link to an item's log on the q page"""
    def __init__(self, itemId, text=None):
        """
        :Parameters:
            itemId : `str`
                a full itemId, e.g. 11041134.2.104
            text : `str`
                If given, this will be displayed instead of the full item
                ID.
        """
        self.itemId = itemId
        self.text = text

    def formatted(self, format):
        split = str(self.itemId).split('.')
        groupId = split[0]
        jobIndex = split[1]
        itemIndex = split[2]
        url = ("http://q/cgi-bin/job_log.cgi?farm=mrg&"
               "groupid=%(groupId)s&"
               "jobid=%(jobIndex)s&"
               "jobidx=%(itemIndex)s"
               % (locals()))
        displayText = self.text if self.text is not None else self.itemId
        return format.webLink(displayText, url)


class AnchorLink(WebLink):
    """Link to another spot on the same page."""
    def formatted(self, format):
        contents = format.formatMessage(self.message)
        return format.anchorLink(contents, self.url)


class Anchor(WebLink):
    """Link to another spot on the same page."""
    def formatted(self, format):
        contents = format.formatMessage(self.message)
        return format.anchor(contents, self.url)


class Date(Message):
    """Date that will be converted to a calendar day."""
    def __init__(self, posixTime):
        """
        :Parameters:
            posixTime : `int|float`
                UTC date in seconds since epic.
        """
        self.posixTime = posixTime

    def formatted(self, format):
        return format.date(self.posixTime)


class Newline(Message):
    """Newline/break symbol"""
    def formatted(self, format):
        return format.newline


class Bar(Message):
    """Horizontal bar for headers or dividers."""
    def formatted(self, format):
        return format.bar()


class Header(Message):
    """A major header for a new section."""
    def __init__(self, message, level=1, bar=False):
        self.message = message
        self.level = level
        self.bar = bar

    def formatted(self, format):
        text = format.formatMessage(self.message)
        text = format.header(text, level=self.level)
        if self.bar:
            text = format.newline + format.bar()
        return text


class Bold(Message):
    def __init__(self, message):
        self.message = message

    def formatted(self, format):
        text = format.formatMessage(self.message)
        return format.bold(text)


def timeString(seconds):
    """
    :Parameters:
        seconds : `int`
    :Returns:
        A string in <hour>:<minute>:<second> format, or <minute>:<second>
        if less than 1 hour.
    :Rtype:
        `str`
    """
    sec     = seconds %  60
    hours   = seconds // 3600
    minutes = (seconds // 60) - (hours * 60)
    if hours:
        return "%d:%.2d:%.2d" % (hours, minutes, sec)
    return "%d:%.2d" % (minutes, sec)

def dateString(seconds):
    """
    :Parameters:
        seconds : `int`
            posixTime
    :Returns:
        A sortable date string, e.g. 2012-08-17 12:23:45 (Wed Aug 24) format.
    :Rtype:
        `str`
    """
    timeTuple = time.localtime(seconds)
    return time.strftime("%m-%d %H:%M:%S (%a %b %d)", timeTuple)

def terminalWidth(default=70):
    """
    :Returns:
        The width of the terminal, or default if not in a terminal
    :Rtype:
        `int`
    """
    try:
        return struct.unpack("HHHH", 
                             fcntl.ioctl(sys.stdout.fileno(),
                                         termios.TIOCGWINSZ,
                                         struct.pack("HHHH", 0, 0, 0, 0)))[1]
    except IOError, e:
        return default

colors = [io.color.BG_BLUE,    io.color.BG_CYAN, io.color.BG_GREEN, 
          io.color.BG_MAGENTA, io.color.BG_RED,  io.color.BG_WHITE,
          io.color.BG_YELLOW,  io.color.BOLD,    io.color.FG_BLACK,
          io.color.FG_BLUE,    io.color.FG_CYAN, io.color.FG_GREEN,
          io.color.FG_MAGENTA, io.color.FG_RED,  io.color.FG_WHITE,
          io.color.FG_YELLOW,  io.color.INVERSE, io.color.NORMAL,
          io.color.UNDERLINE]

def colorize(text, color):
    """Wrap the text in the given color, leaving following text normal.
    :Parameters:
        text : `str`
    :Returns:
        Text color frmt
    :Rtype:
        `str`
    """
    return "%s%s%s" % (color, text, io.color.NORMAL)


def decolorize(text):
    """Strip color codes from text.
    :Parameters:
        text : `str`

    :Returns:
        Text without color frmt
    :Rtype:
        `str`
    """
    for c in colors:
        text = text.replace(c, "")
    return text

def emphasizeNumbers(string):
    """
    :Parameters:
        string : `str`
            A string to emphasize numbers in
    :Returns:
        The string with all numbers emphasized for wiki markup.
    :Rtype:
        `str`
    """
    return re.sub(r"(\d+)", r"*\1*", string)

def wrap(message, columns):
    """
    :Parameters:
        message : `str`
            The message to wrap
        columns : `int`
            The number of columns to wrap to.
    :Returns:
        The original message wrapped at the given column width split
        into a list of lines that wrap at the given column.  Attempts
        to leave any special formatting intact, and does not count those
        characters in your column count.
    :Rtype:
        `str list`
    """
    # Some constants
    # 
    normal     = io.color.NORMAL
    formatting = ""
    whiteSpace = (' ', '\n', '\r', '\t')
    newLines   = ('\n', '\r')

    # State within the loop.
    # 
    lines  = []
    line   = ""
    word   = ""
    curCol = 0
    i      = 0

    while i < len(message):
        char = message[i]

        # If the char is a formatting char, record it and continue.
        # 
        if char == '\x1b':
            tmpWord = message[i:i+5]
            clr = [clr for clr in colors if tmpWord.startswith(clr)]
            if clr:
                clr = clr[0]
                formatting += clr
                word += clr
                i += len(clr)
                continue

        # Whitespace
        # 
        elif char in whiteSpace:
            if char in newLines:
                line += word
                if formatting:
                    line += normal
                lines.append(line)
                line = "" + formatting
                curCol = 0
            else:
                line += word + char
                curCol += 1
            word = ""

        # Regular char
        # 
        else:
            curCol += 1
            if curCol > columns:
                if formatting:
                    line += normal
                lines.append(line)
                line = "" + formatting       
                curCol = 0
            word += char

        i += 1

    # Finish
    # 
    if word:
        line += word
    if line:
        if formatting:
            line += normal
        lines.append(line)
    return lines
        
class Table(Message):
    """
    An abstraction for a table, so that tables can be output to wiki, email,
    html, or terminal format more easily.
    """
    def __init__(self, rows=[], header=None, title=None,  colWidths=[], sortable=True):
        """
        :Parameters:
            rows : `str list`
            header : `str list`
            colWidths : `int list`
                If colWidths is given, plainText columns will use these widths
        """
        self.rows = rows
        self.header = header
        self.title = title
        self._colWidths = colWidths
        self.sortable = sortable

    def formatted(self, format):
        """
        :Parameters:
            format : `FORMAT_*`
                The format type from frmt
        :Returns:
            This table formatted in the given format.
        :Rtype:
            `str`
        """
        if isinstance(format, EmailFormat):
            return self.getEmail(format)
        elif isinstance(format, WikiFormat):
            return self.getWiki(format)
        elif isinstance(format, (TerminalFormat,HeyFormat)):
            return self.getText(format)
        raise ValueError("Unrecognized Format: %s" % (str(format)))

    def getWiki(self, format):
        """
        :Parameters:
            format : `Format`
        :Returns:
            The markup for a wiki table.
        :Rtype:
            `str`
        """
        messages = []
        colWidths = self.colWidths()
        if self.title:
            messages.append("h3. %s" % format.formatMessage(self.title))
        messages.append(self._getWikiTableInit())
        if self.header:
            headerCells = format.formatMessages(self.header)
            headerCells = [cell.ljust(colWidths[i])
                           for i,cell in enumerate(headerCells)]
            messages.append("||%s||" % "||".join(headerCells))
        for row in self.rows:
            cells = format.formatMessages(row)
            cells = [cell.ljust(colWidths[i]) for i,cell in enumerate(cells)]
            messages.append("|%s|" % ("|".join(cells)))
        messages.append("{table-plus}")
        message = "\n".join(messages)
        return message

    def _getWikiTableInit(self):
        """
        :Returns:
            Line to initialize a wiki table based on this table's action.s
        :Rtype:
            `str`
        """
        options = [
            "border=1",
            "enableHighlighting=false",
            "columnTypes=S,S,S,S,S,S,S",
            ]
        if self.sortable:
            options.append("sortIcon=true")
        else:
            options.append("enableSorting=false")
        line = "{table-plus:%s}" % "|".join(options)
        return line

    def getEmail(self, format):
        """
        :Parameters:
            format : `Format`
        """
        messages = []

        if self.title:
            messages.append("<b>%s</b><br>" % format.formatMessage(self.title))

        # messages.append('<table collapse="1">')
        messages.append('<table frame="VOID" rules="NONE" border="1" cellspacing="0">')
        headerTag = '<th style="border-top:1px solid #707070;border-bottom:1px solid #707070;border-left:1px solid #707070;border-right:0px solid #707070" height="19" align="LEFT" bgcolor="#D0D0D0"><font size="3">'
        joiner = "</font></th>%s" % headerTag
        if self.header:
            headerCells = format.formatMessages(self.header)
            messages.append("<tr>%s%s</font></th></tr>" % 
                            (headerTag, joiner.join(headerCells)))

        # tdTag = "<td style='border: thin solid #cccccc'>"
        tdTag = '<td style="border-top:0px solid #707070;border-bottom:1px solid #707070;border-left:1px solid #707070;border-right:0px solid #707070" height="19">'
        # tdTag = "<td>"
        joiner = "</td>\n%s" % tdTag
        for row in self.rows:
            cells = format.formatMessages(row)
            messages.append("<tr>%s%s</td></td></tr>\n" % 
                            (tdTag, (joiner.join(cells))))

        messages.append("</table>")
        message = "\n".join(messages)
        return message

    def getText(self, format, colored=True):
        """
        :Parameters:
            format : `Format`
            colored : `bool`
                If colored is False, return without ansi colors.
        """
        
        messages = []
        messages.append("")

        colWidths = self.colWidths()
        
        if self.title:
            messages.append(format.bold(format.formatMessage(self.title)))

        # Preformat all cells to allow wrapping.
        # 
        wrappedRows = []
        allRows = self.allRows()
        for ri,row in enumerate(allRows):
            wrappedRow = []
            for ci,cell in enumerate(row):
                wrappedRow.append(self.wrapCell(ri, ci, format))
            wrappedRows.append(wrappedRow)

        # Header Row
        # 
        if self.header:
            ri = 0
            row = wrappedRows[0]
            numCols = len(row)
            numLines = max([len(row[i]) for i in range(numCols)])
            for lineNum in range(numLines):
                line = ""
                for ci in range(numCols):
                    contents = wrappedRows[ri][ci]
                    if lineNum < len(contents):
                        colWidth = colWidths[ci]
                        cellContents = contents[lineNum]
                        extraWidth = (len(cellContents) -
                                      len(decolorize(cellContents)))
                        colWidth = colWidths[ci] + extraWidth
                        line += "%s " % contents[lineNum].ljust(colWidth)
                    else:
                        line += "%s " % ("".ljust(colWidths[ci]))
                messages.append(line)

        # Data Rows
        # 
        ri = 1 if self.header else 0
        for row in self.rows:
            row = wrappedRows[ri]
            numCols = len(row)
            numLines = max([len(row[i]) for i in range(numCols)])
            for lineNum in range(numLines):
                line = ""
                for ci in range(numCols):
                    contents = wrappedRows[ri][ci]
                    if lineNum < len(contents):
                        colWidth = colWidths[ci]
                        cellContents = contents[lineNum]
                        extraWidth = (len(cellContents) -
                                      len(decolorize(cellContents)))
                        colWidth = colWidths[ci] + extraWidth
                        line += "%s " % contents[lineNum].ljust(colWidth)
                    else:
                        line += "%s " % ("".ljust(colWidths[ci]))
                messages.append(line)
            ri += 1

        # # Data Rows
        # # 
        # for row in self.rows:
        #     rowMessage = ""
        #     for i,cell in enumerate(row):
        #         cellMessage = format.formatMessage(cell)
        #         rowMessage += "%s " % cellMessage.ljust(colWidths[i])
        #     messages.append(rowMessage)

        message = format.newline.join(messages)
        return message
        
    def wrapCell(self, row, col, format):
        """
        :Parameters:
            row : `int`
                Row of the cell.  0 is the header if it exists and the first
                data row otherwise.
            col : `int`
                Column of the cell.  0 is the first column.
            format : `Format`
        :Returns:
            The message in the specified cell, split into lines wrapped to
            a desired width.
        :Rtype:
            `str list`
        """
        allRows = self.allRows()
        cell = allRows[row][col]
        width = self.colWidth(col)
        message = format.formatMessage(cell)
        if self.header and row == 0:
            message = format.bold(message)
        return wrap(message, width)

    def colWidths(self):
        """
        :Returns:
            A list of the column widths for this table.
        :Rtype:
            `int list`
        """
        numCols = self.numCols()
        return [self.colWidth(i) for i in range(numCols)]

    def setColWidth(self, col, width):
        """Set the $column to the max width of $width
        :Parameters:
            col : `int`
            width : `int`
        """
        # Expand the list of explicit column widths if necessary.
        # 
        difference = col - len(self._colWidths)
        if difference > 0:
            self._colWidths += [0] * (difference + 1)
        self._colWidths[col] = width

    def numCols(self):
        """
        :Returns:
            The number of columns in this table.
        :Rtype:
            `int`
        """
        rowLengths = [len(row) for row in self.allRows()]
        return max(rowLengths)

    def rowHeight(self, rowIndex):
        """
        :Returns:
            The number of lines a column spans.  If the text in any cells
            span more than that row's width, wrap the text.
            0 is the header row if it exists and the first data row
            otherwise.
        :Rtype:
            `int`
        """
        maxHeight = 1
        for row in self.allRows():
            for colIndex,cell in enumerate(row):
                maxWidth = self.colWidth(colIndex)
                contents = decolorize(cell)
                if len(contents) > maxWidth:
                    wrapped = wrap(contents, maxWidth)
                    maxHeight = max(maxHeight,len(wrapped.split('\n')))
        return maxHeight

    def colWidth(self, index):
        """
        :Parameters:
            index : `int`
                The index of this column
        :Returns:
            The width of this column in characters.
        :Rtype:
            `int`
        """
        rows = self.allRows()
        cellWidths = []

        # If we're looking up colWidth, we assume we're using a
        # terminal.
        # 
        format = TerminalFormat()

        for row in rows:
            if index < len(row):
                # Format the cell as a terminal string and decolorize it
                # to avoid counting ansi coloring.
                # 
                cellString = format.formatMessage(row[index])
                size = len(decolorize(cellString))
                cellWidths.append(size)
            else:
                cellWidths.append(0)

        if not cellWidths:
            maxWidth = 0
        else:
            maxWidth = max(cellWidths)

        # If a nonzero columnWidth is listed in self._colWidths, use that.
        # Otherwise, determine the width of the longest element.
        # 
        if index < len(self._colWidths) and self._colWidths[index]:
            return self._colWidths[index]
        return maxWidth

    def allRows(self):
        if self.header:
            return [self.header] + self.rows
        return self.rows[:]

class Chart(Table):
    def __init__(self, rows=[], header=None, title=None,
                 colWidths=[], sortable=True, chartType=None,
                 width=None, height=None,
                 subTitle=None, xLabel=None, yLabel=None, legend=None,
                 dataDisplay=None, dataOrientation=None,
                 showShapes=None,
                 rangeAxisUpperBound=None,
                 rangeAxisLowerBound=None
                 ):
        super(Chart, self).__init__(rows=rows, header=header, title=title,
                                    colWidths=colWidths, sortable=sortable)
        self.chartType = chartType
        self.xLabel          = xLabel
        self.yLabel          = yLabel
        self.legend          = legend
        self.height          = height
        self.width           = width
        self.subTitle        = subTitle
        self.dataDisplay     = dataDisplay
        self.dataOrientation = dataOrientation
        self.showShapes      = showShapes
        self.rangeAxisLowerBound = rangeAxisLowerBound
        self.rangeAxisUpperBound = rangeAxisUpperBound

    def formatted(self, format):
        """
        :Parameters:
            format : `FORMAT_*`
                The format type from frmt
        :Returns:
            This table formatted in the given format.
        :Rtype:
            `str`
        """
        if isinstance(format, WikiFormat):
            return self.getWiki(format)
        if isinstance(format, EmailFormat):
            return self.getEmail(format)
        elif isinstance(format, (TerminalFormat,HeyFormat)):
            return ""
        raise ValueError("Unrecognized Format: %s" % (str(format)))

    def getWiki(self, format):
        """
        :Parameters:
            format : `Format`
        :Returns:
            The markup for a wiki table.
        :Rtype:
            `str`
        """
        messages = []
        chartFlags = {}

        # Process flags that have the same attr name as the wiki chart
        # macro.
        # 
        easyFlags = ['xLabel', 'yLabel', 'legend', 'height',
                     'width', 'dataDisplay', 'dataOrientation',
                     'showShapes', 'rangeAxisLowerBound', 'rangeAxisUpperBound']
        for flag in easyFlags:
            value = getattr(self, flag)
            if value:
                chartFlags[flag] = value

        # process remaining flags.
        # 
        if self.chartType:
            chartFlags['type'] = self.chartType

        # Only use the subTitle for now, as the full title is huge.
        # 
        if self.title:
            chartFlags['subTitle'] = self.title

        flagStrings = ["%s=%s" % (flag,val) for flag,val in chartFlags.items()]
        flagString = '|'.join(flagStrings)

        if flagString:
            flagString = ":" + flagString

        messages.append("{chart%s}" % flagString)

        colWidths = self.colWidths()
        if self.header:
            headerCells = format.formatMessages(self.header)
            headerCells = [cell.ljust(colWidths[i])
                           for i,cell in enumerate(headerCells)]
            messages.append("||%s||" % "||".join(headerCells))
        for row in self.rows:
            cells = format.formatMessages(row)
            cells = [cell.ljust(colWidths[i]) for i,cell in enumerate(cells)]
            messages.append("|%s|" % ("|".join(cells)))
        messages.append("{chart}")
        message = "\n".join(messages)
        return message

    def getEmail(self, format):
        """
        :Parameters:
            format : `EmailFormat`
                The format object.  Having this allows us to record the image
                to attach later.
        :Returns:
            A string that will display an embedded image of the this chart
            in the email.
        :Rtype:
            `str`
        """
        chartPath = self._getChartImage()
        cid = chartPath.split(os.sep)[-1]
        message = '<img src="cid:%s">' % (cid)
        format.addImage(cid, chartPath)
        return message

    def _getChartImage(self):
        """
        :Returns:
            The filepath to a matplot lib chart.
        :Rtype:
            `str`
        """
        # DISPLAY doesn't get set in crons, which is the intended use
        # for this tool.  When there's no $DISPLAY env var, matplotlib
        # errors, so make sure it doesn't
        # 
        if not ('DISPLAY' in os.environ and os.environ['DISPLAY']):
            os.environ['DISPLAY'] = ":0.0"
        fig = plt.figure()

        if self.chartType == "xyLine":
            if self.dataOrientation == "vertical":
                independentVar = [row[0] for row in self.rows]
                dependentVars = []
                for i in xrange(1,self.numCols()):
                    column = [row[i] for row in self.rows]
                    dependentVars.append(column)
            else:
                independentVar = self.rows[0]
                dependentVars = self.rows[1:]
            
            # One row, one column, one plot
            # 
            ax = fig.add_subplot(1, 1, 1)

            for dependentVar in dependentVars:
                ax.plot(independentVar, dependentVar)

            ax.xaxis.set_label_text(self.xLabel, size=10)
            ax.yaxis.set_label_text(self.yLabel,size=10)
            ax.grid(True, color='.75')

            if self.title:
                ax.set_title(self.title)

            dpi = 72.0
            # self.width and self.height are in pixels, we need inches.
            # 
            if self.width:
                fig.set_figwidth(self.width/dpi)
            if self.height:
                fig.set_figheight(self.height/dpi)
            
            ylimits = list(ax.get_ylim())
            if self.rangeAxisLowerBound:
                ylimits[0] = float(self.rangeAxisLowerBound)
            if self.rangeAxisUpperBound:
                ylimits[1] = float(self.rangeAxisUpperBound)
            ax.set_ylim(ylimits)

            chartFD,chartPath = tempfile.mkstemp(prefix="td_farm_usage_report_chart_",
                                                 suffix=".png")
            # Close the file descriptor opened.
            # 
            os.close(chartFD)
            fig.savefig(chartPath, dpi=dpi, format='png')
            io.info("chartPath = %s" % (chartPath))
            return chartPath

# Globally defined formats.
# 
FORMAT_DEFAULT = TerminalFormat
# FORMAT_WIKI    = WikiFormat()
# FORMAT_TERM    = TerminalFormat()
# FORMAT_EMAIL   = EmailFormat()
# Format_HEY     = HeyFormat()
# FORMAT_DEFAULT = FORMAT_TERM

