#!/usr/local/bin/python
# DreamWorks Animation LLC Confidential Information.
# TM and (c) 2013 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
"""
"""
from __future__ import with_statement

__author__ = "Michael Ross"

import sys, os, time, json
from ordereddict import OrderedDict
import studioenv
import studio.framework.app
import studio.system.command

from studio.utils.path import Path
from studio import io


class App(studio.framework.app.App):
    """
    Times multiple iterations of a command and stores the results in
    json files.
    """

    def addCmdlineFlags(self, cl):
        """Adds command line flags to the application.
        Parameters cl
                Instance of an studio.utils.cmdline object.
        """
        super(App, self).addCmdlineFlags(cl)

        cl.addArg("command", 
                  "The command to run.  Should be a single argument in "
                  "quotes.",
                  required=False)
        cl.addFlag("-no_ani",
                   "Do not pass an ani to the command.")
        cl.addFlag("-iterations <int>",
                   "Number of times to run the said command.",
                   convert=int,
                   default=1)
        cl.addFlag("-tag <tag>",
                   "Organize this data with this tag.  Tagged data lives in "
                   "directory with other data of the same tag.  If not given, "
                   "the first agument of the command is used."
                   )
        cl.addFlag("-no_log",
                   "Do not log the results"
                   )
        cl.addFlag('-report ...',
                   'Print statistics about the given files.'
                   )

    def configureOptions(self, opts):
        """Configures the application options.
        """
        opts = super(App, self).configureOptions(opts)

        if not opts['report'] and not opts['command']:
            raise ValueError("You must give a command to run or -report")
        if opts['report'] and opts['command']:
            io.warn("Ignoring command, only reporting")
        if not opts['tag'] and opts['command']:
            opts['tag'] = opts['command'].split()[0].split("/")[-1]
        return opts

    def main(self):
        """Application entry point."""
        super(App, self).main()
        if self.opts['report']:
            self.report()
        else:
            self.timeCommands()

    def report(self):
        files = self.opts['report']
        if not files:
            raise ValueError("No files given to report on")
        timings = Timing.fromFiles(files)
        stats = Stats(timings)
        io.write(stats.toString())

    def timeCommands(self):
        """
        Time the commands given in the options.
        """
        if not self.opts['no_log']:
            io.write("Storing results in %s" % (self.getOutputDir()))
        for i in range(self.opts['iterations']):
            log = self.timeCommand(self.opts['command'], i)
            if not self.opts['no_log'] and log:
                io.write("Results stored in %s" % (log))

    def timeCommand(self, command, iteration):
        """
        Runs a command and dumps some timing info to stdout and logfiles.
        :Parameters:
            command : `str`
                Commandline to run.
        :Returns:
            Path to the file where the timing data was stored, or None
            if no timing data was stored.
        :Rtype:
            `str|None`
        """
        st = time.time()

        ani = None if self.opts['no_ani'] else self.ani
        if self.opts['no_ani']:
            cmd = studio.system.command.Command(command)
        else:
            cmd = studio.system.command.AniCommand(command, ani=ani,
                                                   successValues=range(256))
        try:
            cmd.run()
            results = cmd.getResults()
            io.write("\n".join(results[0]))
            io.write("\n".join(results[1]))
        except Exception, e:
            io.error(e)

        et = time.time()

        output = ["Elapsed Time: %.2f seconds" % (et-st),
                  "CWD: %s" % (os.getcwd()),
                  "COMMAND: %s" % (" ".join(sys.argv)),
                  "Start: %s" % (time.ctime(st)),
                  "End: %s" % (time.ctime(et)),
                  "PID: %s" % (cmd.pid),
                  "PPID: %s" % (os.getpid()),
                  "Iteration: %s" % iteration,
                  "Studio: %s" % os.environ["STUDIO"],
                  "Host: %s" % os.environ["HOST"],
                  "Tag: %s" % self.opts['tag'],
                  ]
        
        # output = "  ".join(output)

        timing = Timing(startTime=st,
                        endTime=et,
                        command=" ".join(sys.argv),
                        cwd=os.getcwd(),
                        iteration=iteration,
                        studio=os.environ['STUDIO'],
                        host=os.environ['HOST'],
                        tag=self.opts['tag'],
                        pid=cmd.pid,
                        ppid=os.getpid(),
                        )
        output = timing.getOutput()
        io.write(output, io.color.FG_CYAN)

        if not self.opts['no_log']:
            timingDir = self.getOutputDir()
            filename = "%s_%s_%s" % (os.getenv("STUDIO"), os.getpid(), cmd.pid)
            dest = os.path.join(timingDir, filename)

            # Write a log of the timing.
            # 
            if not os.path.exists(timingDir):
                os.makedirs(timingDir)
            with open(dest, 'w') as f:
                f.write(output + "\n")
            return dest
        return None

    def getOutputDir(self):
        return "/studio/smekday/work/%s/timings/%s" % (os.getenv("USER"),
                                                       self.opts['tag'])

class Timing(object):
    def __init__(self, 
                 startTime=None,
                 endTime=None,
                 command=None,
                 cwd=None,
                 iteration=None,
                 studio=None,
                 host=None,
                 tag=None,
                 pid=None,
                 ppid=None,
                 ):
        self.startTime = startTime
        self.endTime = endTime
        self.command = command
        self.cwd = cwd
        self.iteration = iteration
        self.studio = studio
        self.host = host
        self.tag = tag
        self.pid = pid
        self.ppid = ppid

    _attrs = [
        "elapsedTime",
        "startTime",
        "endTime",
        "command",
        "cwd",
        "iteration",
        "studio",
        "host",
        "tag",
        "pid",
        "ppid"]

    def elapsedTime():
        doc = "Time to run the command"
        def fget(self):
            return self.endTime - self.startTime
        def fset(self, val):
            pass
        return locals()
    elapsedTime = property(**elapsedTime())

    def getDict(self):
        """
        :Returns:
            Dict containing attrs for storable attrs of this Timing.
        :Rtype:
            `dict`
        """
        return OrderedDict([(attr, getattr(self, attr)) for attr in self._attrs])

    def getOutput(self):
        """
        :Returns:
            A string representing this timing object.
        :Rtype:
            `str`
        """
        return json.dumps(self.getDict())
        
    @classmethod
    def fromFile(cls, filepath):
        with open(filepath, "r") as f:
            d = json.load(f)
        return cls.fromDict(d)

    @classmethod
    def fromDict(cls, d):
        instance = cls()
        for k,v in d.items():
            setattr(instance, k, v)
        return instance

    @classmethod
    def fromFiles(cls, filepaths):
        return [cls.fromFile(fp) for fp in filepaths]        


class Stats():
    def __init__(self, timings):
        self.timings = timings
        self.calculate()

    def calculate(self):
        runTimes = [t.elapsedTime for t in self.timings]
        sortedTimes = sorted(runTimes)
        numTimes = len(runTimes)
        
        self.minTime = sortedTimes[0]
        self.avgTime = sum(sortedTimes) / numTimes
        self.q1Time  = sortedTimes[numTimes//3] 
        self.medTime = sortedTimes[numTimes//2]
        self.q3Time  = sortedTimes[numTimes*3//4]
        self.maxTime = sortedTimes[-1]

    def toString(self):
        return """mean: %(avgTime)f
median: %(medTime)f
min: %(minTime)f
max: %(maxTime)f
Q1: %(q1Time)f
Q3: %(q3Time)f""" % (self.__dict__)
        
if __name__ == '__main__':
    App().run(sys.argv)

# TM and (c) 2013 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
