#!/usr/local/bin/python
import os
os.popen4('firefox mydw/')
