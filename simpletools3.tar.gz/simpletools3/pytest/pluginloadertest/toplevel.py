message = "this is defined in the top level"
