from ..toplevel import message

print message

class APlugin(object):
    pass
