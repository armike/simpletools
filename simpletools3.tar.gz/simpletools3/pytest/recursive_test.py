#!/usr/local/bin/python
# DreamWorks Animation LLC Confidential Information.
# TM and (c) 2012 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.

"""
Application module for recursive_test.
"""
__version__ = "$Id: recursive_test,v 1.15 2008/04/01 01:31:32 foo Exp $"
__source__ = "$Source: /rel/cvsroot/cmd/src_cmd/src_create/templates/python_program/recursive_test,v $"
__author__ = "Michael Ross"

import sys, os
import studioenv
import studio.framework.app


class App(studio.framework.app.App):
    """
    :TMPL: Give a short description of your application. This text also shows
    up as the cmdline description.
    Do not rename this class.  It should be named "App".
    See pydoc studio.framework.app.App for more information.
    For information on intermediate application classes see:
    http://mydw.anim.dreamworks.com/display/PYDOC/Application+Framework+Intermediate+Classes
    """

    def addCmdlineFlags(self, cl):
        """Adds command line flags to the application.

        :Parameters:
            cl
                Instance of an studio.utils.cmdline object.
        """
        super(App, self).addCmdlineFlags(cl)

        # Add flags to cl which is an AniCmdline instance.
        cl.addFlag('-example_flag',
                   'Flag that gets converted to a python int.',
                   convert=int)

    def configureOptions(self, opts):
        """Configures the application options.

        :Parameters:
            opts
                Dictionary of options parsed from command line flags.
        """
        opts = super(App, self).configureOptions(opts)

        # From here you can access self.ani, and self.extraArgs.
        # This is a pass through for modifying opts before main.
        
        return opts

    def main(self):
        """Application entry point."""
        super(App, self).main()
        import pdb; pdb.set_trace()
        # From here you can access self.opts, self.ani, and self.extraArgs.


if __name__ == '__main__':
    App().run()


# TM and (c) 2012 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
