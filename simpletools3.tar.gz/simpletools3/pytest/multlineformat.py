#!/usr/local/bin/python
import sys
sys.stdout.write("one: %d\n"
                 "two: %d" % (1, 2))
