#!/usr/local/bin/python
import sys
sys.stdout.write("one "
                 "two "
                 "three.")
