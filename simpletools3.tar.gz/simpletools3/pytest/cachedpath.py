#!/usr/local/bin/python
# DreamWorks Animation LLC Confidential Information.
# TM and (c) 2014 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.

import os
import studioenv
from studio.utils.path import Path,Stat


class CachedPath(Path):

    def __init__(self, pathValue, ani=None, ignoreVars=[]):
        # required for setting up the Path settings.
        Path.__init__(self, pathValue, ani, ignoreVars)
        self._stat = Stat(Path(pathValue, ani).expand())

    def getAccessTime(self):
        """
        Return the last access time (atime) of a file, reported by os.stat().

        :Returns:
            Type: int
        """
        return self._stat.accessTime

    def getCreationTime(self):
        """
        Return the metadata change time (ctime) of a file, reported by os.stat().
        Technically, this is the "inode change time" which is the equivalent of
        "ls -lc" output.  The actual creation time of a path is not stored
        anywhere.

        :Returns:
            Type: int
        """
        return self._stat.createTime

    def getSize(self):
        """
        Return the size of a file, reported by os.stat().

        :Returns:
            Type: int
        """
        return self._stat.size

    def getOwner(self):
        """
        Return the name of the owner of this file or directory.  This follows
        symbolic links.

        :Returns:
            Type: str
        """
        return self._stat.owner

    def isFile(self):
        """
        Return True for a file, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isFile()

    def isDir(self):
        """
        Return True for a directory, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isDir()

    def isLink(self):
        """
        Return True for a symlink, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isLink()

    def isCharDevice(self):
        """
        Return True for a character special device, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isCharDevice()

    def isBlockDevice(self):
        """
        Return True for a block special device, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isBlockDevice()

    def isNamedPipe(self):
        """
        Return True for a FIFI (named pipe), False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isNamedPipe()

    def isSocket(self):
        """
        Return True for a socket, False otherwise.

        :Rtype:
            `bool`
        """
        return self._stat.isSocket()


    def isExecutable(self, **kwargs):
        """
        Check for executability by the given entity.  Defaults to checking for
        executability be the owner.

        :Parameters:
            by : `int`
                Check executability for the user, group, or others.  Acceptable
                values are stat.S_IXUSR, stat.S_IXGRP, stat.S_IXOTH.
        """
        return self._stat.isExecutable(**kwargs)

    def isWritable(self, **kwargs):
        """
        Check for writability by the given entity.  Defaults to checking for
        writability be the owner.

        :Parameters:
            by : `int`
                Check writability for the user, group, or others.  Acceptable
                values are stat.S_IWUSR, stat.S_IWGRP, stat.S_IWOTH.
        """
        return self._stat.isWritable(**kwargs)

    def isReadable(self, **kwargs):
        """
        Check for readability by the given entity.  Defaults to checking for
        readability be the owner.

        :Parameters:
            by : `int`
                Check readability for the user, group, or others.  Acceptable
                values are stat.S_IRUSR, stat.S_IRGRP, stat.S_IROTH.
        """
        return self._stat.isReadable(**kwargs)

# TM and (c) 2013 DreamWorks Animation LLC.  All Rights Reserved.
# Reproduction in whole or in part without prior written permission of a
# duly authorized representative is prohibited.
